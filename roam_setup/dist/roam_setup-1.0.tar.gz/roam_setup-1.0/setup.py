from distutils.core import setup

setup(
    name="roam_setup",
    version="1.0",
    author="HuiyaoShu",
    authot_mail="1941879233@qq.com",
    url="",
    description="Optimize xla hlo operator execution order through ILP method",
    packages=["roam"],
)