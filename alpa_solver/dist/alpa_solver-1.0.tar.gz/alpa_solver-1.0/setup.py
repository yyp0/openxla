from distutils.core import setup

setup(
    name="alpa_solver",
    version="1.0",
    author="HuiyaoShu",
    authot_mail="1941879233@qq.com",
    url="",
    description="Support auto sharding based on alpa.",
    packages=["alpa"],
)